# BMI3

## External links

- Hal (2023-2024): https://drive.google.com/file/d/1QB0Z1TYR2U0DTcqwliKIKlJaJ68Umau2/view?usp=sharing
