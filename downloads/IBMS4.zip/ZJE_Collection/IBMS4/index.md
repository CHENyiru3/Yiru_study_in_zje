# IBMS4

## External links

- Hal (2024-2025): https://drive.google.com/file/d/1XcHq_gENuok68vWcGgfdZlpxAXnygs9J/view?usp=sharing
