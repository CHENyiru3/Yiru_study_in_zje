# MATH

## External links

- Calculus (2021-2022): https://drive.google.com/file/d/1KUHEEFDBXyBm7Oh1rY_DLn2DcPFOQed7/view?usp=sharing
- Statistics (2021-2022): https://drive.google.com/file/d/1vnRG-aoylkFqrY6-cSYmbtZSIeNBYlim/view?usp=sharing
