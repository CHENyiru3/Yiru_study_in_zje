# PoN3

## Contributors

- Yiru: [notes](Yiru/index.md)
- Yue: [PDF materials](Yue/)

## Files

- Browse Yiru notes: [Yiru/](Yiru/)
- Browse Yue PDFs: [Yue/](Yue/)

## External links

- Hal (2023-2024): https://drive.google.com/file/d/1DXCndsKcLVPyI3PtXEGB4igvw_cncc89/view?usp=sharing
