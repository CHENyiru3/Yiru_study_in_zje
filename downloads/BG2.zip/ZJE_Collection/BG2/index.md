# BG2

## Contributors

- Yiru: [notes and PDFs](Yiru/index.md)

## Files

- Browse Yiru materials: [Yiru/](Yiru/)

## External links

- Hal (2022-2023): https://drive.google.com/file/d/1M41n2IJuvcm_0eYSWqiJpg2-tatguquG/view?usp=sharing
