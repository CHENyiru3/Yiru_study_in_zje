# IBMS3

## Contributors

- Yiru: [main materials](Yiru/index.md)
- Xiaoran_etal: [additional materials](Xiaoran_etal/)

## Files

- Browse Yiru materials: [Yiru/](Yiru/)
- Browse Xiaoran_etal materials: [Xiaoran_etal/](Xiaoran_etal/)

## External links

- Hal (2023-2024): https://drive.google.com/file/d/1_0Snof-NLIY3lqJHfND0-KcFXpHnJM2W/view?usp=sharing
