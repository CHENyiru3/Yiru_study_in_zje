# CBSB3
! Please notice, this course has been replaced by CMML3 since 2022 class.

## External links

- Hal (2023-2024): https://drive.google.com/file/d/1aiyIviT2sEW57mjtEKqtddtFxK4n8C4I/view?usp=sharing
