# Contents of 思维导图IFBS_lxr.zip

Download: hosted externally (see the Google Drive folder linked from [Zips Index](../ZIPS_INDEX.md)).

- 思维导图IFBS/theme1/1.12-1.16 Urinary System.xmind
- 思维导图IFBS/theme1/1.2-1.3 The heart.xmind
- 思维导图IFBS/theme1/1.4 Blood Pressure.pdf
- 思维导图IFBS/theme1/1.5 control of blood flow.pdf
- 思维导图IFBS/theme1/1.6 1.7 Fluid balance and cardiovascular function.xmind
- 思维导图IFBS/theme1/1.8 Haemostasis.xmind
- 思维导图IFBS/theme1/1.9-1.11 Lung.xmind
- 思维导图IFBS/theme2/2.1-2.3+最后一节.xmind
- 思维导图IFBS/theme2/2.10 2.12运动l骨骼肌肉系统.xmind
- 思维导图IFBS/theme2/2.11smooth muscle.xmind
- 思维导图IFBS/theme2/2.4-2.5 The integumentarysystem(1).xmind
- 思维导图IFBS/theme2/2.4-2.5 The integumentarysystem.xmind
- 思维导图IFBS/theme2/2.6 Calcium and phosphate handling in the kidney.xmind
- 思维导图IFBS/theme2/2.7-2.8 bone structure, composition, function, remodeling.xmind
- 思维导图IFBS/theme2/2.9 Skeletal Muscle.xmind
- 思维导图IFBS/theme2/倒数第二节 钙磷disorder.xmind
- 思维导图IFBS/theme3/3.1 Glucose metabolism and Energy balance.xmind
- 思维导图IFBS/theme3/3.10 Absorption of fluid electrolytes vitamins and iron.xmind
- 思维导图IFBS/theme3/3.13 Skeletal muscle metabolism.xmind
- 思维导图IFBS/theme3/3.14-3.16 Energy homeostasis.xmind
- 思维导图IFBS/theme3/3.3 stomach.xmind
- 思维导图IFBS/theme3/3.4 Small intestine .xmind
- 思维导图IFBS/theme3/3.5-6liver.xmind
- 思维导图IFBS/theme3/3.7-3.9 Digestion and Absorption of lipid, proteins, and CHO.xmind
- 思维导图IFBS/theme4/4.2-4.4 HPO axis and prolactin.xmind
- 思维导图IFBS/theme4/4.5-4.6 4.8 4.11 homeostasis and HPA axis.xmind
- 思维导图IFBS/theme4/4.7 4.10 4.12 System functions.xmind
- 思维导图IFBS/theme4/4.9 4.13 GIT adaptations.xmind
