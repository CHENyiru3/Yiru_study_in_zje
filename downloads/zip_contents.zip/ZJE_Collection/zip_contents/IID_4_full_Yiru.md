# Contents of IID_4_full_Yiru.zip

Download: hosted externally (see the Google Drive folder linked from [Zips Index](../ZIPS_INDEX.md)).

- IID_4_full/NotebookLLM_Topic_1.pdf
- IID_4_full/NotebookLLM_Topic_4.pdf
- IID_4_full/NotebookLLM_Topic_5_EVA.pdf
- IID_4_full/NotebookLLm_Topic_3.pdf
- IID_4_full/Topic 0 basic concept of immunology.md
- IID_4_full/Topic 1 Innate Immune system.md
- IID_4_full/Topic 1.5 Trained Innate Immunity.md
- IID_4_full/Topic 10 what I need to know for exam.md
- IID_4_full/Topic 11 Macrophage.md
- IID_4_full/Topic 12 Diseases.md
- IID_4_full/Topic 2 Inflammation algorithm.md
- IID_4_full/Topic 3 T-Cell.md
- IID_4_full/Topic 4 ILC, Innate lymphoid cells.md
- IID_4_full/Topic 5 B cell.md
- IID_4_full/Topic 6 Auto-immune disease.md
- IID_4_full/Topic 7 System exhaustion and cytokine storms.md
- IID_4_full/Topic 8 Immunometablism.md
- IID_4_full/Topic 9 monoclonal antibodies.md
- IID_4_full/index.md
