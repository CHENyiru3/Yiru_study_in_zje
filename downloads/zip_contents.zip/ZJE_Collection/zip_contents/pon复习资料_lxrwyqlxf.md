# Contents of pon复习资料_lxrwyqlxf.zip

Download: hosted externally (see the Google Drive folder linked from [Zips Index](../ZIPS_INDEX.md)).

- pon复习资料/1.1 Neuroscience.xmind
- pon复习资料/1.2 Presynaptic Release.xmind
- pon复习资料/10.1 10.2+13.1  Neuronal Diseases.xmind
- pon复习资料/11.1 visual system.docx
- pon复习资料/12.1 Spinal and brain mechanisms ofmovement control.xmind
- pon复习资料/12.1 movement control.xmind
- pon复习资料/13.2 Social Neuroscience.xmind
- pon复习资料/2.1 Expression Mechanisms of Long-Term Plasticity.xmind
- pon复习资料/2.2 Plasticity_and_Learning_Summary.docx
- pon复习资料/2.2 Synaptic Plasticity and Learning in the Brain.xmind
- pon复习资料/3.1 Inhibitory Function.xmind
- pon复习资料/3.1Inhibitory_Function_Lecture_Summary.docx
- pon复习资料/3.2.docx
- pon复习资料/4.1 Learning and Memory.xmind
- pon复习资料/4.2.docx
- pon复习资料/5.1 Attention and Emotion.xmind
- pon复习资料/6.1 6.2.docx
- pon复习资料/7.1 Neuroimaging.xmind
- pon复习资料/7.2 Mood, Habits and Addiction.docx
- pon复习资料/8.1 Critical period plasticity.pptx
- pon复习资料/8.1 Critical periods.pdf
- pon复习资料/8.1 Critical_Periods.docx
- pon复习资料/8.2 NeurodevelopmentalDisorders.xmind
- pon复习资料/9.1 Inhibitory dysfunction in schizophrenia and epilepsy.docx
- pon复习资料/pon疾病.docx
