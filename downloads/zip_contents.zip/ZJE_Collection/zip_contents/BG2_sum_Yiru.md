# Contents of BG2_sum_Yiru.zip

Download: hosted externally (see the Google Drive folder linked from [Zips Index](../ZIPS_INDEX.md)).

- BG2_sum/Collection of disease.pdf
- BG2_sum/Collection of technology.pdf
- BG2_sum/calculation.pdf
- BG2_sum/index.md
