# Contents of PoN3_full_Yiru.zip

Download: hosted externally (see the Google Drive folder linked from [Zips Index](../ZIPS_INDEX.md)).

- PoN3_full/1.1 Introduction and Refresh.md
- PoN3_full/1.2 Presynaptic release.md
- PoN3_full/10.1, 2 Neurodegenerative disease.md
- PoN3_full/10.2 Neurodegeneration disease- Parkinson's disease and Prion disease.md
- PoN3_full/12.1 Brain and spinal cord of movement control.md
- PoN3_full/13.2 Social neuroscience- Theory of mid, empathy, mirror neurons and aggression.md
- PoN3_full/2.1 Long- term plasticity.md
- PoN3_full/2.2 Synaptic plasticity.md
- PoN3_full/3.1 GABAergic inhibitory function.md
- PoN3_full/3.2 Interneuron Diversity.md
- PoN3_full/4.2 Learning and memory.md
- PoN3_full/5.1 Attention and emotion.md
- PoN3_full/6.1 Rewards, punishment, reinforcement learning.md
- PoN3_full/6.2 Schemas and decision making.md
- PoN3_full/7.1 Neuroimaging.md
- PoN3_full/7.2 Mood, habits, and addiction.md
- PoN3_full/final_exam/.DS_Store
- PoN3_full/final_exam/Experiments Summary.md
- PoN3_full/final_exam/Overall review.md
- PoN3_full/final_exam/index.md
- PoN3_full/index.md
