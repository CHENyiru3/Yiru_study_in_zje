# Contents of GP2_sum_Yiru.zip

Download: hosted externally (see the Google Drive folder linked from [Zips Index](../ZIPS_INDEX.md)).

- GP2_sum/GP提纲.pdf
- GP2_sum/index.md
