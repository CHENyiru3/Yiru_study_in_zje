# Contents of BG导图合集_lxrwyqlxf.zip

Download: hosted externally (see the Google Drive folder linked from [Zips Index](../ZIPS_INDEX.md)).

- ╡╝═╝/1 Genetic variation.pdf
- ╡╝═╝/1 Genetic variation.xmind
- ╡╝═╝/10 Developmental Genetics.pdf
- ╡╝═╝/10 Developmental Genetics.xmind
- ╡╝═╝/11  Study Gene Function and Model Human Diseases in Post-Genome Era.xmind
- ╡╝═╝/11 Study Gene Function and Model Human Diseases in Post-Genome Era.pdf
- ╡╝═╝/12 Genetic Testing.pdf
- ╡╝═╝/12 Genetic Testing.xmind
- ╡╝═╝/13 Genetic testing and risk assessment for complex diseases.pdf
- ╡╝═╝/13 Genetic testing and risk assessment for complex diseases.xmind
- ╡╝═╝/14 Genetic Treatment Approaches & Gene Therapy.pdf
- ╡╝═╝/14 Genetic Treatment Approaches & Gene Therapy.xmind
- ╡╝═╝/2 patterns of inheritance.pdf
- ╡╝═╝/3 Maternal inheritance and mitochondrial disease.pdf
- ╡╝═╝/3 Maternal inheritance and mitochondrial disease.xmind
- ╡╝═╝/4 Multifactorial Diseases.pdf
- ╡╝═╝/5 Cell Division and Chromosomes.pdf
- ╡╝═╝/5 Cell Division and Chromosomes.xmind
- ╡╝═╝/6 The Human Genome.xmind
- ╡╝═╝/7  Population genetics.xmind
- ╡╝═╝/8 Cancer Genetics and Genomics.pdf
- ╡╝═╝/8 Cancer Genetics and Genomics.xmind
- ╡╝═╝/9 Sequencing techniques and discovery.pdf
- ╡╝═╝/9 Sequencing techniques and discovery.xmind
